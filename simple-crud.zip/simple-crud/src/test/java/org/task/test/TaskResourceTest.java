/**
 * 
 */
package org.task.test;
import io.quarkus.test.common.http.TestHTTPEndpoint;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.ws.rs.core.MediaType;
import org.junit.jupiter.api.*;
import org.task.Application.controller.TaskController;
import org.task.Application.entity.TaskEntity;
import org.task.Application.model.Task;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import static io.restassured.RestAssured.given;

import java.util.List;

/**
 * Write Test cases here
 */

@QuarkusTest
@TestHTTPEndpoint(TaskController.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TaskResourceTest {

	
	@GET
    @Path("all/task")
    public List<PanacheEntityBase> getAllOrders() {return TaskEntity.listAll(); }

    @GET
    @Path("{id}")
    public Task findById(@PathParam("id") Long id) {
    	Task task = TaskEntity.findById(id);
         return order;
    }

  
}
