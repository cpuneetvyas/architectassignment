create table task (
       taskid bigint auto_increment,
       priority varchar(255),
       status varchar(255);
       title varchar(255),
       projectid varchar(255),
       duedate DATE;
       primary key (id),
       FOREIGN KEY (projectid) REFERENCES Project(projectid)
    );
    
    create table project (
       projectid bigint auto_increment,
       projectname varchar(255),
       taskid bigint;
       primary key (projectid),
FOREIGN KEY (taskid) REFERENCES Task(taskid)
      
       
        );


INSERT INTO task (priority, status,title,projectid,duedate) VALUES ('High', 'pending',"Task3","P1","20-12-2023");
INSERT INTO task (priority, status,title,projectid,duedate) VALUES ('High', 'pending',"Task3","P1","20-12-2023");
INSERT INTO project (projectname, taskid,title,) VALUES ('P1', 't1',"First Project");
