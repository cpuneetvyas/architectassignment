/**
 * 
 */
package org.task.Application.controller;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import org.task.Application.entity.TaskEntity;
import org.task.Application.model.Task;
import org.task.Application.service.TaskService;

import java.util.List;

/**
 * 
 */
@Path("/taskapi")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class TaskController {

    @Inject
    TaskService taskskService;
    
    @Path("all/task")
    @GET
      public List<Task> get() { return taskskService.getAll();}
    

    @Path("task/{taskId}")
    @GET
      public List<Task> get(@PathParam("taskId") Long taskId) { return taskskService.getByTaskId(taskId);}
    
    
    @Path("create/task")
       @POST
       public TaskEntity create(Task task){
    	   TaskEntity taskEntity = taskskService.create(task);
           return taskEntity;
       }

    
    @Path("update/task")   
    @PUT
       public TaskEntity update(Task task){
    	   TaskEntity taskEntity = taskskService.update(task);
           return taskEntity;
    }
       
    @Path("/delete/task/{id}")
    @DELETE
          public void delete(@PathParam("id") Long id){
    	   TaskEntity.deleteById(id);
       }}
