/**
 * 
 */
package org.task.Application.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.task.Application.model.Task;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;

/*
 * 
 */
@Entity
@Table(name = "projects")
public class ProjectEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long projectId;

    @Column(name="projectName")
    public String projectName;
    
    //One project can have many tasks
    @OneToMany(mappedBy = "project", orphanRemoval = true)
    private Set<Task> task;

  
}