package org.task.Application.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.task.Application.model.Project;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;




@Entity
@Table(name = "tasks")
public class TaskEntity extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(name="title")
    public String title;

    @Column(name="description")
    public String description;
    
    @Column(name="status")
    public String status;
    
    @Column(name="priority")
    public String priority;
    
    @Column(name="dueDate")
    public Date dueDate;
    
    //Many task can have association with one single project
    @ManyToOne (fetch = FetchType.LAZY)
    @JoinColumn(name = "projectId")
    private Project project;
}