/**
 * 
 */
package org.task.Application.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import org.task.Application.entity.TaskEntity;
import org.task.Application.model.Task;

/**
 * We can have another Layer called DAO objects which service layer will call
 * due to time constraint i am not able to complete.
 */
@ApplicationScoped
public class TaskService {
	// get All Tasks details
	public List<Task> getAll() {
		List<TaskEntity> listAll = TaskEntity.findAll().list();
		// task Long id, String title, String description, String status, String
		// priority, Date dueDate
		return listAll.stream().map(ie -> {
			return new Task(ie.id, ie.title, ie.description, ie.status, ie.priority, ie.dueDate);
		}).collect(Collectors.toList());
	}

	
	// get All Tasks details
		public List<Task> getByTaskId(Long id) {
			List<TaskEntity> listAll = TaskEntity.findById(id);
			// task Long id, String title, String description, String status, String
			// priority, Date dueDate
			return listAll.stream().map(ie -> {
				return new Task(ie.id, ie.title, ie.description, ie.status, ie.priority, ie.dueDate);
			}).collect(Collectors.toList());
		}
//Create Task
	@Transactional
	public TaskEntity create(Task task) {
		TaskEntity taskEntity = new TaskEntity();
		taskEntity.description = task.getDescription();
		taskEntity.dueDate = task.getDueDate();
		taskEntity.priority = task.getPriority();
		taskEntity.status = task.getStatus();
		taskEntity.title = task.getTitle();

		taskEntity.persist();
		return taskEntity;
	}
//Update task
	@Transactional
	public TaskEntity update(Task task) {
		TaskEntity entity = TaskEntity.findById(task.getId());
		/*{
			  "title": "Updated Title",
			  "description": "Updated description of the task",
			  "status": "In Progress",
			  "priority": "Medium",
			  "dueDate": "2024-01-15"
			  // Other fields that can be updated
			}*/
		entity.status=task.getStatus();
		entity.priority=task.getPriority();
		entity.description=task.getDescription();
		entity.title=task.getTitle();
		entity.dueDate=task.getDueDate();
		
		return entity;
	}

	//Delete Task
	@Transactional
	public void delete(Long id) {
		TaskEntity.deleteById(id);
	}

}
